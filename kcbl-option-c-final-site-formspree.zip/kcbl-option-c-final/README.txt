KCBL Option C Final Site Package

This package is the Community + Sponsorship version of the KCBL rebuild, updated with:
- stronger Oahu / Kailua visual style
- Ko'olau-inspired hero background art
- no outdoor basketball court imagery
- sponsor section
- expanded registration / interest form
- Cloudflare Pages friendly static structure

FILES
- index.html
- assets/css/styles.css
- assets/js/site.js
- assets/img/koolau-hero.svg

CURRENT IMAGE SOURCES
The current build still references the existing live KCBL image URLs so the design preserves the current brand imagery immediately.

Before shutting down GoDaddy hosting:
1. Download the live KCBL images you want to keep.
2. Save them in assets/img/
3. Update the image paths in index.html from:
   https://kailuabasketball.com/images/...
   to:
   assets/img/...

FORMSPREE
Replace:
https://formspree.io/f/REPLACE_WITH_YOUR_FORM_ID
with your actual Formspree endpoint.

CLOUDFLARE PAGES DEPLOY
1. Upload this package to a GitHub repo
2. In Cloudflare Pages choose Connect to Git
3. Select the repo
4. Build command: leave blank
5. Output directory: /
6. Deploy
7. Add the custom domain in Cloudflare Pages

GODADDY TO CLOUDFLARE
You do not need to keep GoDaddy hosting if the site is hosted on Cloudflare Pages.
You can keep the domain registered at GoDaddy if you want and still use Cloudflare for DNS + hosting.

NEXT SUGGESTED ADDITIONS
- sponsor logos row
- FAQ for parents
- season dates / registration deadlines
- payment integration
- volunteer / coach application flow
